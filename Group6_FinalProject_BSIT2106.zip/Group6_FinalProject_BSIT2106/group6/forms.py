# ---------------- IMPORTS ----------------
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Length, EqualTo
from wtforms import RadioField, DateField
from wtforms import FileField
from flask_wtf.file import FileAllowed, FileRequired

class RegisterForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=20)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=5)])
    confirm = PasswordField("Confirm Password", validators=[EqualTo('password', "Passwords must match!")])
    gender = RadioField("Gender", choices=[("Male", "Male"), ("Female", "Female")], validators=[DataRequired()])
    birthday = DateField("Birthday", format="%Y-%m-%d", validators=[DataRequired()])
    address = StringField("Address", validators=[DataRequired(), Length(min=5)])
    submit = SubmitField("Register")


class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class ModuleForm(FlaskForm):
    title = StringField('Module Title', validators=[DataRequired()])
    description = TextAreaField('Description')
    file = FileField('Module File', validators=[
        FileRequired(),
        FileAllowed(['pdf', 'docx', 'pptx'], 'Documents only!')
    ])
    submit = SubmitField('Upload Module')
