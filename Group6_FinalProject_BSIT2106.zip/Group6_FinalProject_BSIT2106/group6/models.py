# ---------------- IMPORTS ----------------
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Initialize the database object
db = SQLAlchemy()


# ---------------- USER TABLE ----------------
class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    gender = db.Column(db.String(10))
    birthday = db.Column(db.Date)
    address = db.Column(db.String(255))
    role = db.Column(db.String(20), default='student')  # ddefault student


# -- MODULES --
class Modules(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    filename = db.Column(db.String(150), nullable=False)
    date_uploaded = db.Column(db.DateTime, default=datetime.utcnow)
    slug = db.Column(db.String(150), unique=True)

    def __repr__(self): 
        return f"<Module {self.title}>"


# -- QUIZ --
class Quizzes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255))
    module_id = db.Column(db.Integer, db.ForeignKey('modules.id'), nullable=True)


class Questions(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quizzes.id'))
    question_text = db.Column(db.Text)


class Choices(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'))
    choice_text = db.Column(db.String(255))
    is_correct = db.Column(db.Boolean, default=False)


# -- USER PROGRESS --
class UserProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    module_id = db.Column(db.Integer, db.ForeignKey('modules.id'), nullable=False)
    quiz_score = db.Column(db.Integer)
    completed = db.Column(db.Boolean, default=False)

    user = db.relationship('Users', backref='progress')
    module = db.relationship('Modules', backref='progress')
