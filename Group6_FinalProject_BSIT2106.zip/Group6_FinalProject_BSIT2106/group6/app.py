from flask import Flask, render_template, redirect, url_for, session, request, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from forms import RegisterForm, LoginForm, ModuleForm
from models import db, Users, Modules, Quizzes, Questions, Choices, UserProgress
import pymysql
import os

# If you plan to use MySQL in production, pymysql helps SQLAlchemy talk to it.
# It's safe to keep even if you use SQLite for local dev.
pymysql.install_as_MySQLdb()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'  # Secret key helps keep sessions/forms safe
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost:3306/presentation'   
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Folder to save uploaded files
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Connect the database (models.py) to this Flask app
db.init_app(app)

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', title='Home')


# ---------------- REGISTER ----------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()

    if form.validate_on_submit():
        username = form.username.data.strip()

        # Check if username already exists in the DB
        if Users.query.filter_by(username=username).first():
            return render_template('register.html', form=form, error="Username already exists!")

        new_user = Users(
            username=username,
            password=generate_password_hash(form.password.data),
            gender=form.gender.data,
            birthday=form.birthday.data,
            address=form.address.data,
            role='student'  # default role
        )

        db.session.add(new_user)
        db.session.commit()

        # Log the user in automatically
        session['user_id'] = new_user.id
        session['user'] = new_user.username
        session['role'] = new_user.role

        return redirect(url_for('dashboard'))

    return render_template('register.html', form=form)


# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        user = Users.query.filter_by(username=form.username.data.strip()).first()

        if user and check_password_hash(user.password, form.password.data):
            session['user_id'] = user.id
            session['user'] = user.username
            session['role'] = user.role
 
            return redirect(url_for('dashboard'))

        else:
            flash('Invalid credentials', 'danger')

    return render_template('login.html', form=form, title='Login')


# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user', None)
    session.pop('role', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

from flask import render_template, session, redirect, url_for
from models import Users

# ---------------- PROFILE ----------------
@app.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user = Users.query.get(session["user_id"])

    return render_template("profile.html", user=user)

# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash("Please log in first", "danger")
        return redirect(url_for('login'))

    user = Users.query.get(session['user_id'])

    # Get all modules
    modules = Modules.query.all()

    # Build dictionary: module_id → quiz (only modules that have quizzes)
    quizzes_by_module = {
        quiz.module_id: quiz
        for quiz in Quizzes.query.filter(Quizzes.module_id.isnot(None)).all()
    }

    # Get user progress
    progress = UserProgress.query.filter_by(user_id=user.id).all()
    user_progress = {p.module_id: p for p in progress}

    # Render template and pass the new dict
    return render_template("dashboard.html", modules=modules, quizzes_by_module=quizzes_by_module, user_progress = user_progress)


# ---------------- ADMIN ROUTES ----------------
@app.route('/upload', methods=['GET', 'POST'])
def upload_module():
    # Ensure only admin can upload
    if session.get('role') != 'admin':
        flash('Access denied.', 'danger')
        return redirect(url_for('dashboard'))

    form = ModuleForm()  # <-- create the form instance

    if form.validate_on_submit():
        file = form.file.data
        filename = secure_filename(file.filename)
        if not filename:
            flash("Invalid file name.", "danger")
            return redirect(url_for('upload_module'))

        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        # Create slug
        slug_base = form.title.data.strip().lower().replace(" ", "-")
        slug = slug_base
        idx = 1
        while Modules.query.filter_by(slug=slug).first():
            slug = f"{slug_base}-{idx}"
            idx += 1

        new_module = Modules(
            title=form.title.data.strip(),
            description=form.description.data.strip(),
            filename=filename,
            slug=slug
        )

        db.session.add(new_module)
        db.session.commit()
        flash("Module uploaded successfully!", "success")
        return redirect(url_for('upload_module'))

    return render_template('upload.html', form=form)  # <-- Pass form here


@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/module/<slug>')
def view_module(slug):
    module = Modules.query.filter_by(slug=slug).first_or_404()
    return render_template('view_module.html', module=module)


# ---------------- CREATE QUIZ ----------------
@app.route('/create_quiz', methods=['GET', 'POST'])
def create_quiz():
    if session.get('role') != 'admin':
        flash('Access denied.', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        module_id = request.form.get('module_id')
        module_id = int(module_id) if module_id else None

        quiz = Quizzes(title=title, module_id=module_id)
        db.session.add(quiz)
        db.session.commit()
        flash("Quiz created. Add questions now.", "success")
        return redirect(url_for('add_question', quiz_id=quiz.id))

    modules = Modules.query.all()
    return render_template('create_quiz.html', modules=modules)

# ---------------- ADD QUESTION ----------------
@app.route('/add_question/<int:quiz_id>', methods=['GET', 'POST'])
def add_question(quiz_id):
    quiz = Quizzes.query.get_or_404(quiz_id)

    if request.method == 'POST':
        q_text = request.form.get('question', '').strip()
        c1 = request.form.get('choice1', '').strip()
        c2 = request.form.get('choice2', '').strip()
        c3 = request.form.get('choice3', '').strip()
        c4 = request.form.get('choice4', '').strip()
        correct = request.form.get('correct', '').strip()  # expecting "1"/"2"/"3"/"4"

        if not q_text:
            flash("Question text is required.", "danger")
            return redirect(url_for('add_question', quiz_id=quiz_id))

        question = Questions(quiz_id=quiz_id, question_text=q_text)
        db.session.add(question)
        db.session.commit()

        choices = [c1, c2, c3, c4]
        for i, text in enumerate(choices, start=1):
            if not text:
                continue
            choice = Choices(
                question_id=question.id,
                choice_text=text,
                is_correct=(str(i) == correct)
            )
            db.session.add(choice)

        db.session.commit()
        flash("Question and choices added.", "success")
        return redirect(url_for('add_question', quiz_id=quiz_id))

    return render_template('add_question.html', quiz_id=quiz_id, quiz=quiz)


# ---------------- TAKE QUIZ ----------------
@app.route('/quiz/<int:module_id>', methods=['GET', 'POST'])
def take_quiz(module_id):
    if 'user_id' not in session:
        flash("Please login first", "danger")
        return redirect(url_for('login'))

    user = Users.query.get(session['user_id'])
    quiz = Quizzes.query.filter_by(module_id=module_id).first()
    if not quiz:
        flash("No quiz for this module", "warning")
        module = Modules.query.get(module_id)
        return redirect(url_for('view_module', slug=module.slug) if module else url_for('dashboard'))

    questions = Questions.query.filter_by(quiz_id=quiz.id).all()

    if request.method == 'POST':
        score = 0
        for q in questions:
            selected_choice_id = request.form.get(str(q.id))
            correct_choice = Choices.query.filter_by(question_id=q.id, is_correct=True).first()
            if correct_choice and selected_choice_id and str(correct_choice.id) == str(selected_choice_id):
                score += 1

        progress = UserProgress.query.filter_by(user_id=user.id, module_id=module_id).first()
        if not progress:
            progress = UserProgress(user_id=user.id, module_id=module_id)
        progress.quiz_score = score
        progress.completed = True
        db.session.add(progress)
        db.session.commit()

        flash(f"Quiz submitted! Your score: {score}/{len(questions)}", "success")
        return redirect(url_for('dashboard'))

    # Prepare questions + choices
    q_and_choices = [(q, Choices.query.filter_by(question_id=q.id).all()) for q in questions]

    return render_template('take_quiz.html', quiz=quiz, q_and_choices=q_and_choices, questions=questions)

#  ------ About Us ----
@app.route("/about_us")
def about_us():
    return render_template("about_us.html")


# ---------------- STARTUP ----------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        # Only create default users if there aren't any admins yet
        if not Users.query.filter_by(role='admin').first():
            admin1 = Users(username='kian', password=generate_password_hash('admin123'), role='admin')
            admin2 = Users(username='katrina', password=generate_password_hash('admin123'), role='admin')
            admin3 = Users(username='mikko', password=generate_password_hash('admin123'), role='admin')
            admin4 = Users(username='aj', password=generate_password_hash('admin123'), role='admin')

            student = Users(username='student', password=generate_password_hash('student123'), role='student')

            db.session.add_all([admin1, admin2, admin3, admin4, student])
            db.session.commit()

    # Run the app
    app.run(debug=True)
